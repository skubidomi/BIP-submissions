function pine = find_the_pine(I)
    
end