function output_img = myconv(input_img, kernel)
    
end
