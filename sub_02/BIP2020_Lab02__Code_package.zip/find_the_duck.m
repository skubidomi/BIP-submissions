function duck = find_the_duck(I)
	
end