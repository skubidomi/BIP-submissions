function [TH] = threshold(IMG, level)
    
end