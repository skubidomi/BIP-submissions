function [PAD] = pad_image(varargin)
    
end