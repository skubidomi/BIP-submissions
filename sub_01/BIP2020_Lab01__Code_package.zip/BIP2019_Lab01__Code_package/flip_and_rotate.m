function [VER, HOR, ROT] = flip_and_rotate(IMG)
    
end