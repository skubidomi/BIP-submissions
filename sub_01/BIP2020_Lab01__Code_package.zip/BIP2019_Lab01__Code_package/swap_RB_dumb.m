function [BGR] = swap_RB_dump(RGB)
    
end